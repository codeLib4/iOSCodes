//
//  NestedView.swift
//  PopToRoot
//
//  Created by MTPC-99 on 02/07/22.
//

import SwiftUI

struct NestedView: View {
    
    @EnvironmentObject var viewModel:ViewModel
    var fromDetail:String
    
    var body: some View {
        VStack {
            Text("From detail" + fromDetail)
                .font(.largeTitle)
            Button {
                for _ in 0..<viewModel.path.count {
                    viewModel.path.removeLast()
                }
            } label: {
                Text("Pop to root")
            }
        }
        .navigationTitle("Nested")
    }
}

struct NestedView_Previews: PreviewProvider {
    static var previews: some View {
        NestedView(fromDetail: "")
    }
}
