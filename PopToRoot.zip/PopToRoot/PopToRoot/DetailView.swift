//
//  DetailView.swift
//  PopToRoot
//
//  Created by MTPC-99 on 02/07/22.
//

import SwiftUI

struct DetailView: View {
    
    var selectedIndex:Int
    @EnvironmentObject var viewModel:ViewModel
    
    var body: some View {
        VStack {
            Text("User selected index \(selectedIndex)")
                .font(.largeTitle)

            Button {
                viewModel.path.append("nested")
            } label: {
                Text("Go to Nested View")
            }
        }
        .navigationDestination(for: String.self) { value in
            NestedView(fromDetail: value).environmentObject(viewModel)
        }
        .navigationTitle("Detail")
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView(selectedIndex: 0)
    }
}
