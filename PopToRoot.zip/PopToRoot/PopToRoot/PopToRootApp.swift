//
//  PopToRootApp.swift
//  PopToRoot
//
//  Created by MTPC-99 on 02/07/22.
//

import SwiftUI

@main
struct PopToRootApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
