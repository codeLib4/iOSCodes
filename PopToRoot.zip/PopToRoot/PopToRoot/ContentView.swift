//
//  ContentView.swift
//  PopToRoot
//
//  Created by MTPC-99 on 02/07/22.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var viewModel = ViewModel()
    
    var body: some View {
        NavigationStack(path: $viewModel.path) {
            List(0..<10) { i in
                NavigationLink(value: i) {
                    Label("Row \(i)", systemImage: "\(i).circle")
                }
            }
            .navigationDestination(for: Int.self) { i in
                DetailView(selectedIndex: i).environmentObject(viewModel)
            }
            .navigationTitle("NavigationStack")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


class ViewModel : ObservableObject {
    
    @Published var path:NavigationPath = NavigationPath()
    
}
