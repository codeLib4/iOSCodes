//
//  ViewController.swift
//  GroupYoutube
//
//  Created by MTPC-99 on 30/06/22.
//

import UIKit

struct Section {
    let title:String
    var article:[Article]
}

class ViewController: UIViewController {
    
    
    lazy var tableView :UITableView = {
        let tv = UITableView(frame: self.view.frame,style: .grouped)
        tv.dataSource  = self
        tv.delegate = self
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.register(NewsTableViewCell.self, forCellReuseIdentifier: "NewsTableViewCell")
        return tv
    }()
    
    var dataSource = [Section]()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(tableView)
        fetchNews()
    }
    
    //You can fetch from api. Here i have fetch from local json file
    func fetchNews() {
        if let path = Bundle.main.path(forResource: "News", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path),options: .mappedIfSafe)
                let newsResponse = try JSONDecoder().decode(NewsResponse.self, from: data)
                
                //Lets create sections
                newsResponse.articles?.forEach({ article in
                    if !self.dataSource.contains(where: {$0.title == article.publishedDate}) {
                        self.dataSource.append(Section(title: article.publishedDate ?? "", article: [article]))
                    } else {
                        guard let index = self.dataSource.firstIndex(where: { $0.title == article.publishedDate}) else { return }
                        self.dataSource[index].article.append(article)
                    }
                })
                
                DispatchQueue.main.async { [self] in
                    tableView.reloadData()
                }
                
            } catch let error {
                print(error.localizedDescription)
            }
        }
    }


}

extension ViewController : UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource[section].article.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return dataSource[section].title
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NewsTableViewCell", for: indexPath) as! NewsTableViewCell
        let article = dataSource[indexPath.section].article[indexPath.row]
        cell.textLabel?.text = article.cleanURL
        return cell
    }
    
    
}
