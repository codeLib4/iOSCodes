//
//  NewsResponse.swift
//  GroupYoutube
//
//  Created by MTPC-99 on 30/06/22.
//

import Foundation

struct NewsResponse: Codable {
    let status: String?
    let articles: [Article]?
}

// MARK: - Article
struct Article: Codable {
    let title, publishedDate, cleanURL: String?

    enum CodingKeys: String, CodingKey {
        case title
        case publishedDate = "published_date"
        case cleanURL = "clean_url"
    }
}
