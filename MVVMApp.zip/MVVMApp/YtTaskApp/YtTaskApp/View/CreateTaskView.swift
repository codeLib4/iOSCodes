//
//  CreateTaskView.swift
//  YtTaskApp
//
//  Created by MTPC-99 on 03/05/22.
//

import SwiftUI

struct CreateTaskView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CreateTaskView_Previews: PreviewProvider {
    static var previews: some View {
        CreateTaskView()
    }
}
