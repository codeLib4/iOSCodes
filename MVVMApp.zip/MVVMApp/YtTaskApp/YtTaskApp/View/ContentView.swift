//
//  ContentView.swift
//  YtTaskApp
//
//  Created by MTPC-99 on 03/05/22.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject private var viewModel:ViewModel = ViewModel()
    @State var isPresent:Bool = false
    
    
    var body: some View {
        VStack {
            Text("Task")
                .font(.title2)
                .fontWeight(.bold)
                .frame(maxWidth:.infinity,alignment: .leading)
                .padding()
            
            //MARK :- Timer View
            timerView
            
            if viewModel.tasks.isEmpty {
                
                Spacer()
                VStack {
                    Text("There is no task for you")
                        .font(.title)
                    
                    Button {
                        self.isPresent = true
                    } label: {
                        Circle()
                            .fill(Color(uiColor: .systemBlue))
                            .frame(width:44,height:44)
                            .overlay(
                                Image(systemName: "plus")
                                    .foregroundColor(.white)
                            )
                    }
                    .sheet(isPresented: $isPresent) {
                        CreateTaskView()
                    }
                }
                Spacer()
                
            } else {
                //Our Task List UI
            }
            
            
        }
    }
}

extension ContentView {
    private var timerView : some View {
        return VStack {
            HStack {
                Text("00:00:00")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                Spacer()
            }.padding(EdgeInsets(top: 16, leading: 16, bottom: 0, trailing: 16))
            HStack {
                Image(systemName: "circle.fill")
                    .foregroundColor(.white)
                Text("Your Task")
                    .foregroundColor(.white)
                Spacer()
            }.padding(EdgeInsets(top: 4, leading: 16, bottom: 16, trailing: 16))
            
        }.background(Color(uiColor: .systemBlue))
            .cornerRadius(20)
            .padding(.horizontal,20)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
