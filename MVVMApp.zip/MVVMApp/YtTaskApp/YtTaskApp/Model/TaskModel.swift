//
//  TaskModel.swift
//  YtTaskApp
//
//  Created by MTPC-99 on 03/05/22.
//

import Foundation

struct TaskModel {
    
}
