//
//  ViewModel.swift
//  YtTaskApp
//
//  Created by MTPC-99 on 03/05/22.
//

import Foundation

class ViewModel : ObservableObject {
    @Published var tasks : [TaskModel] = [TaskModel]()
}
